# Danh mục ảnh minh chứng DT028

Ảnh A01–A09 chụp trực tiếp cửa sổ Visual Studio Code 1.142.0 trên máy, vùng terminal
PowerShell, với lệnh chạy và output thật của chương trình Julia.

| Mã | Ca | Tệp |
|---|---|---|
| A01 | VD01 — [1,2,2,2,4], x = 2 | `01_vi_du_1.png` |
| A02 | VD02 — cùng mảng, x = 3 | `02_vi_du_2.png` |
| A03 | TK01 — [1,1,1,5,9], x = 1 | `03_tu_thiet_ke_1.png` |
| A04 | TK02 — [0,3,7,7], x = 7 | `04_tu_thiet_ke_2.png` |
| A05 | BIEN01 — [1,2], x = 1 | `05_bien_1.png` |
| A06 | BIEN02 — mảng rỗng | `06_bien_2.png` |
| A07 | BIEN03 — [5,5,5], x = 5 | `07_bien_3.png` |
| A08 | LOI01 — input không hợp lệ | `08_input_khong_hop_le.png` |
| A09 | Toàn bộ bộ kiểm thử | `09_tong_ket_kiem_thu.png` |
| A10 | Clone sạch và chạy lại | Sinh viên bổ sung sau khi đẩy GitHub |
| A11 | GitHub repo/commit C | Sinh viên bổ sung sau khi đẩy GitHub |

Ảnh giao diện trang mô phỏng: `../mo_phong_desktop.png` và `../mo_phong_mobile.png`
(chụp bằng Chrome headless ở kích thước 1440×1000 và 390×844).

A10/A11 không được tạo giả. Sinh viên thực hiện theo `docs/HUONG_DAN_GIT.md`, sau đó
bổ sung ảnh và cập nhật mục 4.9 của báo cáo.
